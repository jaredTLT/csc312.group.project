# csc312.group.project

TEMPLATES - This is where we store our HTML Files
STATIC - This is where we do our CSS
WEBAPP - This is where we do our methods in pyhton

WEBAPP :
-models; Using Classes to store information
-views ; Defining our methods and sending it to HTML
